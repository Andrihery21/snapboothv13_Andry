import AdminDashboardComponent from '../components/admin/AdminDashboard';

// Ce fichier sert de redirection vers le composant AdminDashboard dans le dossier components/admin
export default AdminDashboardComponent;
