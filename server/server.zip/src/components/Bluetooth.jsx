import React from 'react';
import { Bluetooth as BluetoothIcon } from 'lucide-react';
import { Logger } from '../../lib/logger';

const logger = new Logger('Bluetooth');

export function Bluetooth() {
  const handleClick = () => {
    logger.log('Bluetooth button clicked');
    // Dans une implémentation réelle, vous pourriez ouvrir une interface Bluetooth ici
    alert('Fonctionnalité Bluetooth non disponible sur cette plateforme');
  };

  return (
    <button 
      className="share-button bluetooth-button" 
      onClick={handleClick}
      title="Partager via Bluetooth"
    >
      <BluetoothIcon size={24} />
      <span>Bluetooth</span>
    </button>
  );
}

export default Bluetooth;
