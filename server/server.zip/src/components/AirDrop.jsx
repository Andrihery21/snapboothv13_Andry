import React from 'react';
import { Share2 } from 'lucide-react';
import { Logger } from '../../lib/logger';

const logger = new Logger('AirDrop');

export function AirDrop() {
  const handleClick = () => {
    logger.log('AirDrop button clicked');
    // Dans une implémentation réelle, vous pourriez ouvrir une interface AirDrop ici
    alert('Fonctionnalité AirDrop non disponible sur cette plateforme');
  };

  return (
    <button 
      className="share-button airdrop-button" 
      onClick={handleClick}
      title="Partager via AirDrop"
    >
      <Share2 size={24} />
      <span>AirDrop</span>
    </button>
  );
}

export default AirDrop;
