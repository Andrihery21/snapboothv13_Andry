import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { supabase } from '../../../lib/supabase';
import { Logger } from '../../../lib/logger';
import { Image, Download, Trash2, Share } from 'lucide-react';

const logger = new Logger('PhotoGridGrouped');

export default function PhotoGridGrouped({ eventId, onPhotoSelect }) {
  const [photos, setPhotos] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [groupedPhotos, setGroupedPhotos] = useState({});

  useEffect(() => {
    if (!eventId) {
      setPhotos([]);
      setGroupedPhotos({});
      setIsLoading(false);
      return;
    }

    const fetchPhotos = async () => {
      try {
        setIsLoading(true);
        setError(null);
        
        logger.info(`Chargement des photos pour l'événement ${eventId}`);
        
        const { data, error } = await supabase
          .from('photos')
          .select('*')
          .eq('event_id', eventId)
          .order('created_at', { ascending: false });
          
        if (error) throw error;
        
        setPhotos(data);
        
        // Grouper les photos par date
        const grouped = data.reduce((acc, photo) => {
          const date = new Date(photo.created_at).toLocaleDateString();
          if (!acc[date]) {
            acc[date] = [];
          }
          acc[date].push(photo);
          return acc;
        }, {});
        
        setGroupedPhotos(grouped);
      } catch (err) {
        logger.error('Erreur lors du chargement des photos', err);
        setError(err.message);
      } finally {
        setIsLoading(false);
      }
    };

    fetchPhotos();
  }, [eventId]);

  const handleDownload = async (photo) => {
    try {
      const { data, error } = await supabase.storage
        .from('photos')
        .download(photo.path);
        
      if (error) throw error;
      
      const url = URL.createObjectURL(data);
      const a = document.createElement('a');
      a.href = url;
      a.download = `photo-${photo.id}.jpg`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    } catch (err) {
      logger.error('Erreur lors du téléchargement de la photo', err);
    }
  };

  const handleDelete = async (photoId) => {
    if (!confirm('Êtes-vous sûr de vouloir supprimer cette photo ?')) return;
    
    try {
      const photoToDelete = photos.find(p => p.id === photoId);
      
      // Supprimer le fichier du stockage
      const { error: storageError } = await supabase.storage
        .from('photos')
        .remove([photoToDelete.path]);
        
      if (storageError) throw storageError;
      
      // Supprimer l'entrée de la base de données
      const { error: dbError } = await supabase
        .from('photos')
        .delete()
        .eq('id', photoId);
        
      if (dbError) throw dbError;
      
      // Mettre à jour l'état local
      setPhotos(photos.filter(p => p.id !== photoId));
      
      // Mettre à jour les photos groupées
      const newGroupedPhotos = { ...groupedPhotos };
      Object.keys(newGroupedPhotos).forEach(date => {
        newGroupedPhotos[date] = newGroupedPhotos[date].filter(p => p.id !== photoId);
        if (newGroupedPhotos[date].length === 0) {
          delete newGroupedPhotos[date];
        }
      });
      setGroupedPhotos(newGroupedPhotos);
      
    } catch (err) {
      logger.error('Erreur lors de la suppression de la photo', err);
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-purple-500"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 p-4 rounded-md text-red-700">
        <p>Erreur: {error}</p>
      </div>
    );
  }

  if (!eventId) {
    return (
      <div className="bg-blue-50 p-4 rounded-md text-blue-700">
        <p>Veuillez sélectionner un événement pour voir les photos.</p>
      </div>
    );
  }

  if (Object.keys(groupedPhotos).length === 0) {
    return (
      <div className="bg-gray-50 p-4 rounded-md text-gray-700">
        <p>Aucune photo trouvée pour cet événement.</p>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {Object.entries(groupedPhotos).map(([date, datePhotos]) => (
        <div key={date} className="space-y-4">
          <h3 className="text-lg font-medium text-gray-700 border-b pb-2">{date}</h3>
          
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {datePhotos.map(photo => (
              <motion.div
                key={photo.id}
                className="relative group bg-white p-2 rounded-lg shadow-sm hover:shadow-md transition-shadow"
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => onPhotoSelect && onPhotoSelect(photo)}
              >
                <div className="aspect-w-4 aspect-h-3 overflow-hidden rounded-md bg-gray-100">
                  <img
                    src={`${supabase.storage.from('photos').getPublicUrl(photo.path).data.publicUrl}`}
                    alt={`Photo ${photo.id}`}
                    className="object-cover w-full h-full"
                    loading="lazy"
                  />
                </div>
                
                <div className="mt-2 flex items-center justify-between">
                  <span className="text-xs text-gray-500">
                    {new Date(photo.created_at).toLocaleTimeString()}
                  </span>
                  
                  <div className="flex space-x-1">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDownload(photo);
                      }}
                      className="p-1 text-gray-500 hover:text-blue-600 transition-colors"
                      title="Télécharger"
                    >
                      <Download size={16} />
                    </button>
                    
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDelete(photo.id);
                      }}
                      className="p-1 text-gray-500 hover:text-red-600 transition-colors"
                      title="Supprimer"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}
