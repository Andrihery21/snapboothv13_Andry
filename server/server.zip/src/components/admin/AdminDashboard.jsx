import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Users, Calendar, Settings, Mail, Loader2, AlertCircle, CheckCircle, LogOut, Tv, PlusCircle, Settings as SettingsIcon, AlertCircle as AlertCircleIcon, Eye, Trash2, Monitor, Info, Camera, X } from 'lucide-react';
import { supabase } from '../../../lib/supabase';
import { listProfiles } from '../../../lib/users';
import { useNavigate } from 'react-router-dom'; 
import { useAuthStore } from '../../../store/auth'; 
import { Logger } from '../../../lib/logger';
import AdminPanel from './AdminPanel';
import ScreenSettingsTest from './ScreenSettingsTest';
import PhotoGridGrouped from './PhotoGridGrouped';
import ScreenSettingsHub from './ScreenSettingsHub';
import CaptureMonitoring from './CaptureMonitoring';

const logger = new Logger('AdminDashboard');

const tabs = [
  { id: 'users', label: 'Utilisateurs', icon: Users },
  { id: 'events', label: 'Événements', icon: Calendar },
  { id: 'email', label: 'Email', icon: Mail },
  { id: 'screen', label: 'Écrans', icon: Tv },
  { id: 'monitoring', label: 'Surveillance des stands', icon: Monitor },
  { id: 'capture', label: 'Tests des interfaces de capture', icon: Camera },
];

export default function AdminDashboard({ onClose }) {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('users');
  const [users, setUsers] = useState([]);
  const [events, setEvents] = useState([]);
  const [photos, setPhotos] = useState([]);
  const [screens, setScreens] = useState([]);
  const [selectedScreenId, setSelectedScreenId] = useState(null);
  const [selectedEventId, setSelectedEventId] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [notification, setNotification] = useState({ show: false, type: '', message: '' });
  
  // États pour les utilisateurs
  const [newUserEmail, setNewUserEmail] = useState('');
  const [newUserPassword, setNewUserPassword] = useState('');
  const [newUserRole, setNewUserRole] = useState('user');

  // États pour les écrans
  const [newScreenName, setNewScreenName] = useState('');
  const [newScreenIpAddress, setNewScreenIpAddress] = useState('');
  const [newScreenSerialNumber, setNewScreenSerialNumber] = useState('');
  const [showAdminPanel, setShowAdminPanel] = useState(false);

  
  // États pour les événements
  const [newEventName, setNewEventName] = useState('');

  // États pour les paramètres d'email
  const [emailTemplate, setEmailTemplate] = useState(
    "Bonjour,\n\nVoici votre photo prise lors de l'événement {{event}}.\n\nCordialement,\nL'équipe SNAP BOOTH"
  );
  
  // États pour les paramètres d'interface
  const [settings, setSettings] = useState({
    animations: true,
    gridColumns: 4,
    printFormat: '10x15',
    autoRotate: true,
    cartoon : true,
    dessin : true,
    univers : true,
    carricature : true,
    screenOrientation : 'Paysage'
  });

  const { logout } = useAuthStore();

  useEffect(() => {
    const fetchData = async () => {
      try {
        setIsLoading(true);
        setNotification({ show: false, type: '', message: '' });

        // Charger les utilisateurs
        if (activeTab === 'users') {
          const profiles = await listProfiles();
          setUsers(profiles);
        }
        
        // Charger les événements
        if (activeTab === 'events') {
          const { data: eventsData, error: eventsError } = await supabase
            .from('events')
            .select('*, photos(count)')
            .order('date', { ascending: false });
            
          if (eventsError) throw eventsError;
          setEvents(eventsData);
        }
        
        //Cahrger les écrans 
        if (activeTab === 'screen') {
          const { data: screensData, error: screensError } = await supabase
            .from('screen')
            .select('*');
  
          if (screensError) throw screensError;
          setScreens(screensData);
        }

      
      } catch (err) {
        console.error('Erreur lors du chargement des données:', err);
        setNotification({ show: true, type: 'error', message: 'Erreur lors du chargement des données' });
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, [activeTab]);

  useEffect(() => {
    // Gérer l'orientation de l'écran
    if (settings.screenOrientation === "Portrait") {
      document.body.classList.add("portrait-mode");
    } else {
      document.body.classList.remove("portrait-mode");
    }
  }, [settings.screenOrientation]); 

  useEffect(() => {
    fetchUsers();
    fetchEvents();
    fetchScreens();
    
    // Récupérer l'événement sélectionné depuis localStorage
    const savedEventId = localStorage.getItem('admin_selected_event_id');
    if (savedEventId) {
      setSelectedEventId(savedEventId);
    }
  }, []);

  useEffect(() => {
    if (selectedEventId) {
      localStorage.setItem('admin_selected_event_id', selectedEventId);
    } else {
      localStorage.removeItem('admin_selected_event_id');
    }
  }, [selectedEventId]);

  const handleLogout = async () => {
    logger.info('Déconnexion');
    await logout();
    navigate('/login');
  };

  const handleCreateUser = async (e) => {
    e.preventDefault();
    try {
      setIsLoading(true);
      setNotification({ show: false, type: '', message: '' });

      // Créer l'utilisateur avec Supabase Auth
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: newUserEmail,
        password: newUserPassword,
        options: {
          data: {
            role: newUserRole
          }
        }
      });

      if (authError) throw authError;

      setNotification({ show: true, type: 'success', message: 'Utilisateur créé avec succès' });
      setNewUserEmail('');
      setNewUserPassword('');
      setNewUserRole('user');

      // Rafraîchir la liste des utilisateurs
      const profiles = await listProfiles();
      setUsers(profiles);

    } catch (err) {
      console.error('Erreur lors de la création de l\'utilisateur:', err);
      setNotification({ show: true, type: 'error', message: err.message });
    } finally {
      setIsLoading(false);
    }
  };

  const handleCreateScreen = async (e) => {
    e.preventDefault();
    try {
      setIsLoading(true);
      setNotification({ show: false, type: '', message: '' });
  
      // Créer un écran
      const { error: screenError } = await supabase
        .from('screen')
        .insert([
          {
            screen_name: newScreenName,
            ip_adress: newScreenIpAddress,
            serial_number: newScreenSerialNumber,
          },
        ]);
  
      if (screenError) throw screenError;
  
      setNotification({ show: true, type: 'success', message: 'Écran ajouté avec succès' });
      setNewScreenName('');
      setNewScreenIpAddress('');
      setNewScreenSerialNumber('');
  
      // Rafraîchir la liste des écrans
      const { data: screensData, error: screensError } = await supabase
        .from('screen')
        .select('*');
  
      if (screensError) throw screensError;
      setScreens(screensData);
    } catch (err) {
      console.error('Erreur lors de la création de l\'écran:', err);
      setNotification({ show: true, type: 'error', message: err.message });
    } finally {
      setIsLoading(false);
    }
  };

  const handleUpdateSettings = async () => {
    try {
      setIsLoading(true);
      setNotification({ show: false, type: '', message: '' });
  
      if (!selectedScreenId) {
        setNotification({ show: true, type: 'error', message: 'Veuillez sélectionner un écran.' });
        return;
      }
  
      // 1. Vérifier si une ligne existe déjà pour cet écran
      const { data: existingSettings, error: selectError } = await supabase
        .from('configuration')
        .select('*')
        .eq('screen_id', selectedScreenId); // Filtrer par screen_id
  
      if (selectError) throw selectError;
  
      if (existingSettings && existingSettings.length > 0) {
        // 2. Mettre à jour la ligne existante
        const { error: updateError } = await supabase
          .from('configuration')
          .update({
            column_number: settings.gridColumns,
            is_transition: settings.animations,
            is_automatic_rotation: settings.autoRotate,
            has_cartoon: settings.cartoon,
            has_dessins: settings.dessin,
            has_univers: settings.univers,
            print_format: settings.printFormat,
            screen_orientation: settings.screenOrientation,
            has_carricature: settings.carricature,
          })
          .eq('id', existingSettings[0].id);
  
        if (updateError) throw updateError;
  
        setNotification({ show: true, type: 'success', message: 'Paramètres mis à jour avec succès' });
      } else {
        // 3. Insérer une nouvelle ligne
        const { error: insertError } = await supabase
          .from('configuration')
          .insert([
            {
              column_number: settings.gridColumns,
              is_transition: settings.animations,
              is_automatic_rotation: settings.autoRotate,
              has_cartoon: settings.cartoon,
              has_dessins: settings.dessin,
              has_univers: settings.univers,
              print_format: settings.printFormat,
              screen_orientation: settings.screenOrientation,
              has_carricature: settings.carricature,
              screen_id: selectedScreenId, // Ajouter screen_id
            },
          ]);
  
        if (insertError) throw insertError;
  
        setNotification({ show: true, type: 'success', message: 'Paramètres enregistrés avec succès' });
      }
    } catch (err) {
      console.error('Erreur lors de la mise à jour des paramètres:', err);
      setNotification({ show: true, type: 'error', message: 'Erreur lors de la mise à jour des paramètres' });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSaveEmailTemplate = async () => {
    try {
      setIsLoading(true);
      setNotification({ show: false, type: '', message: '' });

      // Simuler la sauvegarde du template
      await new Promise(resolve => setTimeout(resolve, 500));

      setNotification({ show: true, type: 'success', message: 'Template d\'email mis à jour avec succès' });
    } catch (err) {
      setNotification({ show: true, type: 'error', message: 'Erreur lors de la mise à jour du template' });
    } finally {
      setIsLoading(false);
    }
  };

  const handleEventChange = (eventId) => {
    setSelectedEventId(eventId);
    // Afficher une notification de confirmation
    if (eventId) {
      const eventName = events.find(e => e.id === eventId)?.name || 'Inconnu';
      setNotification({
        show: true,
        type: 'success',
        message: `Événement actif : ${eventName}`
      });
      setTimeout(() => setNotification({ show: false, type: '', message: '' }), 3000);
    }
  };

  const handleScreenTab = () => {
    return (
      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-semibold text-gray-800">Gestion des écrans</h2>
          <div className="flex space-x-2">
            <button
              onClick={() => navigate('/admin/screen-settings')}
              className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg flex items-center gap-2"
            >
              <SettingsIcon size={18} />
              Configurer les interfaces de capture
            </button>
            <button
              onClick={() => setShowAdminPanel(true)}
              className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg flex items-center gap-2 transition-colors"
            >
              <Tv size={18} />
              Panneau d'administration avancé
            </button>
          </div>
        </div>

        {/* Intégration du ScreenSettingsHub */}
        <ScreenSettingsHub />
      </div>
    );
  };

  // Fonction pour récupérer les utilisateurs
  const fetchUsers = async () => {
    try {
      setIsLoading(true);
      const profiles = await listProfiles();
      setUsers(profiles || []);
      logger.info(`${profiles?.length || 0} utilisateurs récupérés`);
    } catch (error) {
      console.error('Erreur lors de la récupération des utilisateurs:', error);
      setNotification({ show: true, type: 'error', message: 'Erreur lors de la récupération des utilisateurs' });
    } finally {
      setIsLoading(false);
    }
  };

  // Fonction pour récupérer les événements
  const fetchEvents = async () => {
    try {
      setIsLoading(true);
      const { data: eventsData, error: eventsError } = await supabase
        .from('events')
        .select('*, photos(count)')
        .order('date', { ascending: false });
        
      if (eventsError) throw eventsError;
      setEvents(eventsData);
      logger.info(`${eventsData?.length || 0} événements récupérés`);
    } catch (error) {
      console.error('Erreur lors de la récupération des événements:', error);
      setNotification({ show: true, type: 'error', message: 'Erreur lors de la récupération des événements' });
    } finally {
      setIsLoading(false);
    }
  };

  // Fonction pour récupérer les écrans
  const fetchScreens = async () => {
    try {
      setIsLoading(true);
      const { data: screensData, error: screensError } = await supabase
        .from('screen')
        .select('*');
        
      if (screensError) throw screensError;
      setScreens(screensData);
      logger.info(`${screensData?.length || 0} écrans récupérés`);
    } catch (error) {
      console.error('Erreur lors de la récupération des écrans:', error);
      setNotification({ show: true, type: 'error', message: 'Erreur lors de la récupération des écrans' });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <header className="bg-white shadow-md">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-4">
            <h1 className="text-2xl font-bold text-purple-700">Snapbooth Admin</h1>
            <div className="hidden md:flex bg-purple-100 text-purple-800 px-3 py-1 rounded-full text-sm font-medium">
              Version 5.2
            </div>
          </div>
          <button 
            onClick={handleLogout}
            className="flex items-center gap-2 bg-gray-200 hover:bg-gray-300 text-gray-700 px-4 py-2 rounded-lg transition-colors"
          >
            <LogOut size={18} />
            <span className="hidden md:inline">Quitter</span>
          </button>
          {onClose && (
            <button 
              onClick={onClose}
              className="flex items-center gap-2 bg-gray-200 hover:bg-gray-300 text-gray-700 px-4 py-2 rounded-lg transition-colors"
            >
              <X size={18} />
              <span className="hidden md:inline">Fermer</span>
            </button>
          )}
        </div>
      </header>

      {/* Sélecteur global d'événement */}
      <div className="bg-white px-4 py-3 border-b flex items-center justify-between shadow-sm">
        <div className="text-sm text-gray-600 flex items-center gap-2">
          <strong>Événement actif :</strong>{' '}
          {selectedEventId ? (
            <span className="flex items-center gap-1">
              <CheckCircle size={16} className="text-green-500" />
              {events.find((e) => e.id === selectedEventId)?.name || 'Chargement...'}
            </span>
          ) : (
            <span className="flex items-center gap-1 text-yellow-600">
              <Info size={16} />
              Aucun événement sélectionné
            </span>
          )}
        </div>
        <div className="flex items-center gap-2">
          <select
            value={selectedEventId || ''}
            onChange={(e) => handleEventChange(e.target.value)}
            className="text-sm border-gray-300 rounded-md px-3 py-1 focus:ring-purple-500 focus:border-purple-500"
          >
            <option value="">— Choisir un événement —</option>
            {events.map((event) => (
              <option key={event.id} value={event.id}>
                {event.name}
              </option>
            ))}
          </select>
          {!selectedEventId && (
            <div className="text-xs text-gray-500 ml-2">
              Activez un événement pour gérer vos écrans et photos
            </div>
          )}
        </div>
      </div>

      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4">
          <div className="flex space-x-1 overflow-x-auto">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-4 py-3 font-medium text-sm flex items-center gap-2 border-b-2 transition-colors ${
                  activeTab === tab.id ? 'border-purple-600 text-purple-700' : 'border-transparent text-gray-600 hover:text-purple-600'
                }`}
              >
                <tab.icon size={18} />
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </nav>

      {/* Notification */}
      {notification.show && (
        <div className={`fixed top-4 right-4 z-50 p-4 rounded-lg shadow-lg flex items-center gap-3 ${
          notification.type === 'success' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
        }`}>
          {notification.type === 'success' ? (
            <CheckCircle className="text-green-500" size={20} />
          ) : (
            <AlertCircle className="text-red-500" size={20} />
          )}
          <p>{notification.message}</p>
        </div>
      )}

      {/* Loading Indicator */}
      {isLoading && (
        <div className="fixed inset-0 bg-black/20 flex items-center justify-center z-40">
          <div className="bg-white p-4 rounded-lg shadow-lg flex items-center gap-3">
            <Loader2 className="animate-spin text-purple-600" size={24} />
            <p className="text-gray-700 font-medium">Chargement en cours...</p>
          </div>
        </div>
      )}
      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        {isLoading ? (
          <div className="flex justify-center items-center py-12">
            <Loader2 className="w-8 h-8 text-purple-600 animate-spin" />
          </div>
        ) : (
          <>
            {/* Users Tab */}
            {activeTab === 'users' && (
              <div className="space-y-6">
                {/* Create User Form */}
                <div className="bg-white rounded-lg shadow p-6">
                  <h2 className="text-lg font-medium text-gray-900 mb-4">
                    Créer un utilisateur
                  </h2>
                  <form onSubmit={handleCreateUser} className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700">
                        Email
                      </label>
                      <input
                        type="email"
                        value={newUserEmail}
                        onChange={(e) => setNewUserEmail(e.target.value)}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">
                        Mot de passe
                      </label>
                      <input
                        type="password"
                        value={newUserPassword}
                        onChange={(e) => setNewUserPassword(e.target.value)}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">
                        Rôle
                      </label>
                      <select
                        value={newUserRole}
                        onChange={(e) => setNewUserRole(e.target.value)}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"
                      >
                        <option value="user">Utilisateur</option>
                        <option value="admin">Administrateur</option>
                      </select>
                    </div>
                    <button
                      type="submit"
                      className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-purple-600 hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500"
                    >
                      Créer l'utilisateur
                    </button>
                  </form>
                </div>

                {/* Users List */}
                <div className="bg-white rounded-lg shadow overflow-hidden">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Email
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Rôle
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Créé le
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Actions
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {users.map((user) => (
                        <tr key={user.id}>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {user.email}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                              user.role === 'admin'
                                ? 'bg-purple-100 text-purple-800'
                                : 'bg-green-100 text-green-800'
                            }`}>
                              {user.role}
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {new Date(user.created_at).toLocaleDateString('fr-FR')}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            <button className="text-purple-600 hover:text-purple-900">
                              Modifier
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Events Tab */}
            {activeTab === 'events' && (
              <div className="bg-white rounded-lg shadow overflow-hidden">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Nom
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Date
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Photos
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {events.map((event) => (
                      <tr key={event.id}>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {event.name}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {new Date(event.date).toLocaleDateString('fr-FR')}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {event.photos_aggregate?.count || 0}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          <button className="text-purple-600 hover:text-purple-900 mr-4">
                            Modifier
                          </button>
                          <button className="text-purple-600 hover:text-purple-900">
                            Voir les photos
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {/* Email Tab */}
            {activeTab === 'email' && (
              <div className="bg-white rounded-lg shadow p-6">
                <h2 className="text-lg font-medium text-gray-900 mb-4">
                  Template d'email
                </h2>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Contenu de l'email
                    </label>
                    <textarea
                      value={emailTemplate}
                      onChange={(e) => setEmailTemplate(e.target.value)}
                      rows={6}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:border-purple-500 focus:ring-purple-500"
                    />
                  </div>
                  <div>
                    <p className="text-sm text-gray-500 mb-2">Variables disponibles:</p>
                    <ul className="text-sm text-gray-500 list-disc list-inside">
                      <li>{'{{event}}'} - Nom de l'événement</li>
                      <li>{'{{date}}'} - Date de l'événement</li>
                      <li>{'{{photo_url}}'} - URL de la photo</li>
                    </ul>
                  </div>
                  <button
                    onClick={handleSaveEmailTemplate}
                    className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-purple-600 hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500"
                  >
                    Sauvegarder
                  </button>
                </div>
              </div>
            )}

            {/* Screen Tab */}
            {activeTab === 'screen' && handleScreenTab()}

            {/* Monitoring Tab */}
            {activeTab === 'monitoring' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-2xl font-bold text-purple-700">Surveillance des stands</h2>
                </div>
                
                <div className="bg-white p-6 rounded-lg shadow-md">
                  {selectedEventId ? (
                    <ScreenSettingsTest eventId={selectedEventId} />
                  ) : (
                    <div className="p-6 bg-yellow-50 text-yellow-700 rounded-lg flex items-center gap-3">
                      <AlertCircle size={24} />
                      <div>
                        <p className="font-medium">Sélectionnez un événement</p>
                        <p className="text-sm mt-1">Veuillez sélectionner un événement dans l'onglet "Événements" pour afficher la surveillance des stands.</p>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}
            {/* Capture Tab */}
            {activeTab === 'capture' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-2xl font-bold text-purple-700">Gestion des stations de capture</h2>
                </div>
                
                <div className="bg-white p-6 rounded-lg shadow-md">
                  {selectedEventId ? (
                    <>
                      <div className="mb-8">
                        <h3 className="text-lg font-semibold text-purple-600 mb-4 flex items-center gap-2">
                          <Monitor size={18} />
                          Surveillance des stations de capture
                        </h3>
                        
                        <CaptureMonitoring eventId={selectedEventId} />
                      </div>
                      
                      <div className="border-t border-gray-200 pt-8">
                        <h3 className="text-lg font-semibold text-purple-600 mb-4 flex items-center gap-2">
                          <Camera size={18} />
                          Tests des interfaces de capture
                        </h3>
                        
                        <p className="text-gray-600 mb-6">
                          Cette section vous permet de lancer, tester ou vérifier l'état de chaque interface de capture depuis une vue centralisée, sans accéder physiquement à chaque poste.
                          Chaque bouton ouvre l'interface concernée dans un nouvel onglet pour permettre une vérification ou une utilisation parallèle.
                        </p>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          {/* Interface Horizontale */}
                          <div className="bg-purple-50 p-5 rounded-lg border border-purple-200 hover:shadow-md transition-shadow">
                            <div className="flex items-start gap-4">
                              <div className="bg-purple-100 p-3 rounded-full">
                                <Tv size={24} className="text-purple-600" />
                              </div>
                              <div className="flex-1">
                                <h4 className="font-medium text-lg text-gray-800">Écran Horizontal</h4>
                                <p className="text-sm text-gray-500 mt-1">Résolution: 1920x1080 - Effet: Cartoon</p>
                                <div className="flex items-center gap-2 mt-1 text-xs text-gray-400">
                                  <span className="bg-purple-100 text-purple-700 px-2 py-0.5 rounded">Type: horizontal</span>
                                </div>
                                <a 
                                  href={`/capture/horizontal${selectedEventId ? `?eventId=${selectedEventId}` : ''}`}
                                  target="_blank" 
                                  rel="noopener noreferrer"
                                  className="mt-4 inline-flex items-center gap-2 px-4 py-2 rounded-md bg-purple-600 text-white hover:bg-purple-700 transition-colors"
                                >
                                  <Camera size={16} />
                                  Tester l'interface
                                </a>
                              </div>
                            </div>
                          </div>
                          
                          {/* Interface Verticale 1 */}
                          <div className="bg-purple-50 p-5 rounded-lg border border-purple-200 hover:shadow-md transition-shadow">
                            <div className="flex items-start gap-4">
                              <div className="bg-purple-100 p-3 rounded-full">
                                <Tv size={24} className="text-purple-600" />
                              </div>
                              <div className="flex-1">
                                <h4 className="font-medium text-lg text-gray-800">Écran Vertical 1</h4>
                                <p className="text-sm text-gray-500 mt-1">Résolution: 1080x1920 - Effet: Univers</p>
                                <div className="flex items-center gap-2 mt-1 text-xs text-gray-400">
                                  <span className="bg-purple-100 text-purple-700 px-2 py-0.5 rounded">Type: vertical_1</span>
                                </div>
                                <a 
                                  href={`/capture/verticale1${selectedEventId ? `?eventId=${selectedEventId}` : ''}`}
                                  target="_blank" 
                                  rel="noopener noreferrer"
                                  className="mt-4 inline-flex items-center gap-2 px-4 py-2 rounded-md bg-purple-600 text-white hover:bg-purple-700 transition-colors"
                                >
                                  <Camera size={16} />
                                  Tester l'interface
                                </a>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </>
                  ) : (
                    <div className="p-6 bg-yellow-50 text-yellow-700 rounded-lg flex items-center gap-3">
                      <AlertCircle size={24} />
                      <div>
                        <p className="font-medium">Sélectionnez un événement</p>
                        <p className="text-sm mt-1">Veuillez sélectionner un événement dans l'onglet "Événements" pour afficher et gérer les stations de capture.</p>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}
          </>
        )}
      </div>

      {/* Modal pour le panneau d'administration avancé */}
      {showAdminPanel && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center p-4 z-50 overflow-auto">
          <div className="w-full max-w-6xl max-h-[90vh] overflow-auto bg-white rounded-lg shadow-2xl">
            <AdminPanel 
              onClose={() => setShowAdminPanel(false)} 
              initialEventId={selectedEventId} 
            />
          </div>
        </div>
      )}
    </div>
  );
}