import React from 'react';
import { NavLink } from 'react-router-dom';
import { Monitor, Camera, Settings, Image, Layers, Grid3X3, Layout } from 'lucide-react';

const links = [
  { to: '/admin-new/overview', label: 'Événements', icon: Grid3X3 },
  { to: '/admin-new/screens', label: 'Écrans configurés', icon: Monitor },
  { to: '/admin/screen-config', label: 'Configuration des écrans', icon: Layout },
  { to: '/admin-new/photogrid', label: 'Photos', icon: Image },
  { to: '/admin-new/interface', label: 'Interface UI', icon: Settings },
  { to: '/admin-new/surveillance', label: 'Surveillance', icon: Camera },
  { to: '/admin-new/advanced', label: 'Avancé', icon: Layers },
];

export default function AdminNavigation() {
  return (
    <aside className="w-full md:w-60 bg-purple-900 text-white min-h-screen p-4">
      <h1 className="text-2xl font-bold mb-6">SNAP BOOTH Admin</h1>
      <nav className="space-y-2">
        {links.map(({ to, label, icon: Icon }) => (
          <NavLink
            key={to}
            to={to}
            className={({ isActive }) =>
              `flex items-center gap-3 px-4 py-2 rounded hover:bg-purple-800 transition ${
                isActive ? 'bg-purple-800 font-semibold' : 'text-purple-100'
              }`
            }
          >
            <Icon className="w-5 h-5" />
            <span>{label}</span>
          </NavLink>
        ))}
      </nav>
    </aside>
  );
}
