import React from 'react';
import { Outlet } from 'react-router-dom';
import AdminNavigation from './AdminNavigation';

export default function AdminLayout() {
  return (
    <div className="flex flex-col md:flex-row min-h-screen bg-gray-100">
      <AdminNavigation />
      <main className="flex-1 p-4 md:p-6 overflow-auto">
        <Outlet />
      </main>
    </div>
  );
}
