import React, { useState } from 'react';
import { Monitor, Settings, Check } from 'lucide-react';
import { Logger } from '../../../lib/logger';

const logger = new Logger('ScreenSettingsTest');

export default function ScreenSettingsTest({ screen, onClose }) {
  const [testResults, setTestResults] = useState({
    connection: null,
    display: null,
    camera: null
  });
  const [isRunningTests, setIsRunningTests] = useState(false);

  const runConnectionTest = async () => {
    logger.log('Running connection test for screen', screen);
    // Simuler un test de connexion
    setTestResults(prev => ({ ...prev, connection: 'success' }));
    return true;
  };

  const runDisplayTest = async () => {
    logger.log('Running display test for screen', screen);
    // Simuler un test d'affichage
    setTestResults(prev => ({ ...prev, display: 'success' }));
    return true;
  };

  const runCameraTest = async () => {
    logger.log('Running camera test for screen', screen);
    // Simuler un test de caméra
    setTestResults(prev => ({ ...prev, camera: 'success' }));
    return true;
  };

  const runAllTests = async () => {
    setIsRunningTests(true);
    try {
      await runConnectionTest();
      await new Promise(resolve => setTimeout(resolve, 1000)); // Délai pour simulation
      
      await runDisplayTest();
      await new Promise(resolve => setTimeout(resolve, 1000)); // Délai pour simulation
      
      await runCameraTest();
    } catch (error) {
      logger.error('Error running tests', error);
    } finally {
      setIsRunningTests(false);
    }
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg max-w-2xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-gray-800 flex items-center">
          <Monitor className="mr-2" />
          Test de l'écran: {screen?.name || 'Non sélectionné'}
        </h2>
        <button 
          onClick={onClose}
          className="text-gray-500 hover:text-gray-700"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
      </div>

      <div className="mb-6">
        <p className="text-gray-600 mb-4">
          Exécutez des tests pour vérifier que l'écran fonctionne correctement.
        </p>
        
        <button
          onClick={runAllTests}
          disabled={isRunningTests || !screen}
          className={`w-full py-2 px-4 rounded-md flex items-center justify-center ${
            isRunningTests || !screen
              ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
              : 'bg-blue-600 text-white hover:bg-blue-700'
          }`}
        >
          {isRunningTests ? (
            <>
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Exécution des tests...
            </>
          ) : (
            <>
              <Settings className="mr-2" />
              Exécuter tous les tests
            </>
          )}
        </button>
      </div>

      <div className="space-y-4">
        <div className="p-4 border rounded-md">
          <div className="flex items-center justify-between">
            <span className="font-medium">Test de connexion</span>
            {testResults.connection === 'success' && (
              <span className="text-green-500 flex items-center">
                <Check size={16} className="mr-1" />
                Réussi
              </span>
            )}
          </div>
          <p className="text-sm text-gray-500 mt-1">
            Vérifie que l'écran est connecté au réseau.
          </p>
        </div>

        <div className="p-4 border rounded-md">
          <div className="flex items-center justify-between">
            <span className="font-medium">Test d'affichage</span>
            {testResults.display === 'success' && (
              <span className="text-green-500 flex items-center">
                <Check size={16} className="mr-1" />
                Réussi
              </span>
            )}
          </div>
          <p className="text-sm text-gray-500 mt-1">
            Vérifie que l'écran affiche correctement les images.
          </p>
        </div>

        <div className="p-4 border rounded-md">
          <div className="flex items-center justify-between">
            <span className="font-medium">Test de caméra</span>
            {testResults.camera === 'success' && (
              <span className="text-green-500 flex items-center">
                <Check size={16} className="mr-1" />
                Réussi
              </span>
            )}
          </div>
          <p className="text-sm text-gray-500 mt-1">
            Vérifie que la caméra connectée à l'écran fonctionne.
          </p>
        </div>
      </div>
    </div>
  );
}
