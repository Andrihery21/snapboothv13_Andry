// Ce composant est déprécié et a été déplacé vers src/features/admin/ScreenGrid.jsx
// Veuillez mettre à jour vos imports pour utiliser le nouveau chemin

import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

export default function ScreenGrid() {
  const navigate = useNavigate();
  
  useEffect(() => {
    console.warn('Le composant ScreenGrid a été déplacé vers src/features/admin/ScreenGrid.jsx');
    // Redirection vers le nouveau composant
    navigate('/admin/screen-settings');
  }, [navigate]);
  
  return null;
}
