import React, { useEffect, useState } from 'react';
import { Loader2 } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { Logger } from '../../lib/logger';

const logger = new Logger('Effect1');

function Effect1({ imageUrl, onEffectApplied, eventID }) {
  const [isLoading, setIsLoading] = useState(true);
  
  useEffect(() => {
    const applyEffect = async () => {
      try {
        setIsLoading(true);
        logger.log('Applying effect to image', { imageUrl });
        
        // Simuler un traitement d'image
        await new Promise(resolve => setTimeout(resolve, 2000));
        
        // Dans une implémentation réelle, vous pourriez appeler une API pour appliquer des filtres
        // Pour l'instant, on retourne simplement l'image originale
        
        logger.log('Effect applied successfully');
        onEffectApplied(imageUrl);
      } catch (error) {
        logger.error('Error applying effect', error);
        // En cas d'erreur, on retourne quand même l'image originale
        onEffectApplied(imageUrl);
      } finally {
        setIsLoading(false);
      }
    };
    
    applyEffect();
  }, [imageUrl, onEffectApplied]);
  
  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/80 z-10">
      <h2 className="text-2xl font-bold text-white mb-8">Application de l'effet...</h2>
      
      {isLoading ? (
        <div className="flex flex-col items-center">
          <Loader2 className="w-16 h-16 text-white animate-spin mb-4" />
          <p className="text-white">Traitement en cours...</p>
        </div>
      ) : (
        <div className="flex flex-col items-center">
          <img src={imageUrl} alt="Preview" className="max-w-md max-h-96 object-contain mb-4" />
        </div>
      )}
    </div>
  );
}

export default Effect1;
