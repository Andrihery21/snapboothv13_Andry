import React, { useState, useEffect } from 'react';
import { Plus, Trash, Check, X } from 'lucide-react';
import { Logger } from '../../lib/logger';

const logger = new Logger('TemplateManager');

export function TemplateManager() {
  const [templates, setTemplates] = useState([]);
  const [newTemplateName, setNewTemplateName] = useState('');
  const [isAdding, setIsAdding] = useState(false);

  useEffect(() => {
    // Charger les templates depuis le stockage local
    const savedTemplates = localStorage.getItem('photoTemplates');
    if (savedTemplates) {
      try {
        setTemplates(JSON.parse(savedTemplates));
      } catch (error) {
        logger.error('Erreur lors du chargement des templates', error);
      }
    }
  }, []);

  const saveTemplates = (updatedTemplates) => {
    try {
      localStorage.setItem('photoTemplates', JSON.stringify(updatedTemplates));
      setTemplates(updatedTemplates);
    } catch (error) {
      logger.error('Erreur lors de la sauvegarde des templates', error);
    }
  };

  const addTemplate = () => {
    if (!newTemplateName.trim()) return;
    
    const newTemplate = {
      id: Date.now().toString(),
      name: newTemplateName.trim(),
      createdAt: new Date().toISOString()
    };
    
    const updatedTemplates = [...templates, newTemplate];
    saveTemplates(updatedTemplates);
    setNewTemplateName('');
    setIsAdding(false);
  };

  const deleteTemplate = (id) => {
    const updatedTemplates = templates.filter(template => template.id !== id);
    saveTemplates(updatedTemplates);
  };

  return (
    <div className="template-manager">
      <h3 className="text-xl font-semibold mb-4">Gestion des Templates</h3>
      
      <div className="templates-list mb-4">
        {templates.length === 0 ? (
          <p className="text-gray-500">Aucun template disponible</p>
        ) : (
          <ul className="space-y-2">
            {templates.map(template => (
              <li key={template.id} className="flex items-center justify-between p-2 bg-gray-100 rounded">
                <span>{template.name}</span>
                <button 
                  onClick={() => deleteTemplate(template.id)}
                  className="text-red-500 hover:text-red-700"
                >
                  <Trash size={18} />
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>
      
      {isAdding ? (
        <div className="flex items-center space-x-2">
          <input
            type="text"
            value={newTemplateName}
            onChange={(e) => setNewTemplateName(e.target.value)}
            placeholder="Nom du template"
            className="flex-1 p-2 border rounded"
          />
          <button 
            onClick={addTemplate}
            className="p-2 bg-green-500 text-white rounded hover:bg-green-600"
          >
            <Check size={18} />
          </button>
          <button 
            onClick={() => setIsAdding(false)}
            className="p-2 bg-red-500 text-white rounded hover:bg-red-600"
          >
            <X size={18} />
          </button>
        </div>
      ) : (
        <button 
          onClick={() => setIsAdding(true)}
          className="flex items-center space-x-2 p-2 bg-blue-500 text-white rounded hover:bg-blue-600"
        >
          <Plus size={18} />
          <span>Ajouter un template</span>
        </button>
      )}
    </div>
  );
}

export default TemplateManager;
