// Noms des dossiers pour l'organisation des photos
export const PATHS = {
  CAPTURES: 'captures',
  PROCESSED: 'processed'
};
