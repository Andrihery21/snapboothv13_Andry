export const AILAB_CONFIG = {
  API_KEY: 'RkYtEnJ19jyCiO82XllMh0ps6Ggporzs0HIKVjuSGJKQmL7hFDN3vUM5rFeXkIdU',
  BASE_URL: 'https://api.ailabtools.com/v1',
  ENDPOINTS: {
    FACE_FILTER: '/face-filter'
  }
};
